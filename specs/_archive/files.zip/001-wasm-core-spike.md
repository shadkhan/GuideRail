# Spec: WASM Core Spike — matcher, sanitizer, benchmark harness
Status: Draft · Date: 2026-07-17 · ADRs: will produce ADR-0003 (classification architecture)

## Goal (one sentence, user-visible outcome)
Prove the performance claims underneath every other feature: curriculum keyword matching and PII scrubbing run in Rust-WASM inside a real MV3 service worker within budget on Chromebook-class hardware.

## Requirements (numbered, testable)
R1. `packages/core-wasm` Rust crate exposing exactly two boundary functions via wasm-bindgen: `classify(text, pack_id) -> ClassifyResult` and `sanitize(text) -> String`.
R2. `classify` uses the `aho-corasick` crate against a loaded pack's keyword set; returns matched tags + verdict (allow | quiz_gate | unknown). No regex for keyword sets.
R3. `sanitize` scrubs emails, phone formats (IN + US + UK), lat/long coordinates, and listed names via pre-compiled patterns, longest-match first; returns tokenized text (`[EMAIL]`, `[PHONE]`, …).
R4. Pure-Rust core testable with plain `cargo test`; wasm-bindgen confined to a thin `lib.rs` boundary layer; no `unwrap()` in that layer — all boundary fns return Result.
R5. Benchmark harness (`pnpm bench:wasm`): Puppeteer launches real Chrome with the unpacked extension, drives N=1,000 classify calls inside the service worker, reports p50/p95/p99 warm-path and separate cold-start (fresh worker → cached bytes → instantiate → first call).
R6. Results appended to `bench/results/history.csv`; `baseline.json` written only on explicit approval (hook enforces this).
R7. Release profile: `opt-level="s"`, `lto=true`, `codegen-units=1`, `panic="abort"`.

## Out of scope (explicit — the reviewer checks this)
- Any DNR rules, quiz UI, blur logic, or network calls
- Pack signing/distribution (spec 003) — this spike uses one hardcoded test pack
- Name-detection beyond the curated-list + heuristic approach (accept the known weakness; note in ADR)

## Acceptance criteria (how "done" is proven)
- [ ] Test: `cargo test -p core-wasm` green; sanitize test corpus includes ≥30 PII cases incl. Hinglish-adjacent phone/name formats
- [ ] Benchmark: warm-path p95 < 5ms, cold-start < 50ms, measured in real Chrome via the harness (Node-only numbers are not evidence)
- [ ] Size: `.wasm` gzipped < 200KB (`gzip -c | wc -c` output in evidence)
- [ ] Evidence artifact: bench/results/history.csv first row + harness screenshot; ADR-0003 written via adr-writer skill

## Open questions (must be empty before Status: Approved)
- Q1: Curated name-list source for the sanitizer's v1 (ship a small seed list, or defer names to `[NAME]`-off in spike?)
- Q2: Target hardware for the published numbers — which actual low-spec device do you own or can borrow?
