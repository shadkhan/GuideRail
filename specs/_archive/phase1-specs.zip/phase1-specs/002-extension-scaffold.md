# Spec: Extension Scaffold — monorepo, manifest, messaging, storage
Status: Draft · Date: 2026-07-17 · ADRs: none needed (conventions already in CLAUDE.md)

## Goal (one sentence, user-visible outcome)
A loadable, hot-reloading MV3 extension skeleton that every later feature plugs into — installable from `pnpm ext:dev` with the WASM core wired in.

## Requirements (numbered, testable)
R1. pnpm + turbo monorepo: `packages/core-wasm`, `packages/extension`, `packages/quiz-engine` (stub), `services/llm-proxy` (stub); shared tsconfig + eslint + prettier.
R2. `manifest.json` (MV3): service worker module type; `declarativeNetRequest`, `storage`, `alarms`, `scripting` permissions; CSP `extension_pages` includes `wasm-unsafe-eval`; `quiz_gate.html` in `web_accessible_resources`.
R3. Typed message schema in `src/messages.ts`: every `chrome.runtime.sendMessage` payload is a declared discriminated-union type; a lint rule or type guard rejects ad-hoc objects.
R4. Storage schema module `src/storage.ts`: versioned keys (`gr.v1.*`), typed get/set wrappers, migration stub; all listeners registered synchronously at worker top level.
R5. WASM lifecycle manager: cache module bytes on `onInstalled`, lazy-instantiate on first classify, expose `ensureCore()` used by all callers; log cold/warm timing marks consumed by the bench harness.
R6. `pnpm ext:dev`: builds, loads unpacked into Chrome, hot-reloads on change, includes `--reset-storage` flag (stale-pack gotcha).
R7. DNR rule registry `src/dnr/registry.ts`: central integer-ID allocation; no hardcoded rule IDs elsewhere (grep-checkable).

## Out of scope
- Any actual filtering verdict logic, quiz UI, blur CSS, onboarding UI
- Edge browser packaging

## Acceptance criteria (how "done" is proven)
- [ ] Test: vitest suite for messages type guards + storage wrappers green
- [ ] Evidence: screen capture of extension loaded via `pnpm ext:dev`, service worker console showing WASM warm-init timing mark
- [ ] Evidence: kill the worker via chrome://serviceworker-internals, trigger a message, show state survives (storage, not module scope)
- [ ] `web-ext lint` clean on the built manifest

## Open questions (must be empty before Status: Approved)
- Q1: Minimum Chrome version to declare (`minimum_chrome_version`) — pick based on wasm + DNR API needs?
