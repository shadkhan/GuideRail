# Spec: Curriculum Pack Schema & Loader
Status: Draft · Date: 2026-07-17 · ADRs: will produce ADR-0004 (pack format & trust model)

## Goal (one sentence, user-visible outcome)
A parent picks "Class 7 · CBSE" (or "General Homeschool") once, and the extension knows what schoolwork means for that child — packs are content drops, never code releases.

## Requirements (numbered, testable)
R1. Pack = single JSON file, board-agnostic schema: `{id, version, locale, board, grade_band, tags[], allow_domains[], allow_keywords[], quiz_topics[], updated_at}` — schema documented in `docs/pack-schema.md` with a JSON Schema file for validation.
R2. Keywords compile into the Aho-Corasick automaton at pack load; automaton cached in memory per worker life, rebuilt on pack change (rebuild time logged; budget < 100ms for a 10k-keyword pack).
R3. Loader validates against JSON Schema + size cap (≤ 2MB) before activation; invalid pack → keep previous pack, surface error state (never brick filtering).
R4. Packs stored versioned in `chrome.storage.local` (`gr.v1.pack.<id>`); atomic swap on update.
R5. Three seed packs shipped in-extension: `cbse-class7`, `icse-class7`, `homeschool-general` (small but real: ≥300 keywords, ≥50 domains each).
R6. Pack selection API used by onboarding (spec 007): list available, get active per profile, set active.
R7. Update mechanism v1: bundled packs only (no network fetch). Signed remote pack delivery is explicitly deferred — leave a `signature` field reserved in the schema.

## Out of scope
- Remote pack CDN, signing/verification implementation (Phase 3; reserve fields only)
- Pack authoring UI; multi-language keyword variants (Hinglish arrives Phase 3)

## Acceptance criteria (how "done" is proven)
- [ ] Test: schema validation suite (valid, oversized, malformed, wrong-version cases); atomic-swap test proves old pack survives failed update
- [ ] Benchmark: automaton rebuild < 100ms for 10k keywords (harness run, number in evidence)
- [ ] Evidence: three seed packs pass validation; classify() returns correct tags for 20 hand-picked URLs/texts per pack
- [ ] ADR-0004 written (why JSON+JSON-Schema, why bundled-first, trust model reserved fields)

## Open questions (must be empty before Status: Approved)
- Q1: Who curates the seed packs' keyword lists — manual curation session with Claude, or derive from NCERT syllabus PDFs you have from VidyaOS work?
- Q2: grade_band granularity: per-class (7) or band (6–8)?
